ReactDOM.render(
  <Board/>,
  document.getElementById('root')
);
